
enum ElementType
   {
    EMPTY,
    PLAYER1,
    PLAYER2
   }
