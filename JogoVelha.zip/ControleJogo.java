import java.util.Scanner;

class ControleJogo
   {
   final private int         dimension     = 3;
   final private ElementType matrix[][]    = new ElementType[dimension][dimension];
   private ElementType       currentPlayer = ElementType.PLAYER1;
   private Scanner           inputStream;

   ControleJogo()
      {
      super();
      for (int linha = 0; linha < dimension; linha++)
         {
         for (int coluna = 0; coluna < dimension; coluna++)
            {
            matrix[linha][coluna] = ElementType.EMPTY;
            }
         }
      }

   private void changePlayer()
      {
      if (currentPlayer == ElementType.PLAYER1)
         {
         currentPlayer = ElementType.PLAYER2;
         }
      else
         {
         currentPlayer = ElementType.PLAYER1;
         }
      }

   private int getFreePlaces()
      {
      int value = 0;

      for (int linha = 0; linha < dimension; linha++)
         {
         for (int coluna = 0; coluna < dimension; coluna++)
            {
            if (matrix[linha][coluna] == ElementType.EMPTY)
               {
               value++;
               }
            }
         }

      return (value);
      }

   private void getPlayerMovement()
      {
      int movLine = 0;
      int movCol = 0;
      boolean validMov = false;

      while (!validMov)
         {
         System.out.println("There is/are " + getFreePlaces() + " free places.");
         System.out.println();

         System.out.println("Please, do your movement " + currentPlayer + " (" + getSymbol(currentPlayer) + ")");

         System.out.print("\tSelect line (0 - " + (dimension - 1) + ") .: ");
         movLine = readNumber(0, dimension);

         System.out.print("\tSelect column (0 - " + (dimension - 1) + "): ");
         movCol = readNumber(0, dimension);

         System.out.println();

         validMov = (matrix[movLine][movCol] == ElementType.EMPTY);
         }
      matrix[movLine][movCol] = currentPlayer;
      }

   private char getSymbol(ElementType position)
      {
      char answer = '?';

      switch (position)
         {
         case EMPTY:
            answer = ' ';
            break;
         case PLAYER1:
            answer = 'X';
            break;
         case PLAYER2:
            answer = 'O';
            break;
         default:
            answer = '#';
            break;
         }
      return (answer);
      }

   void play()
      {
      boolean endOfGame = false;

      printGame();

      while (!endOfGame)
         {
         getPlayerMovement();
         printGame();

         endOfGame = testEndOfGame();

         if (!endOfGame)
            {
            if (getFreePlaces() == 0)
               {
               endOfGame = true;
               System.out.println("Draw! There is no winner.");
               }
            }

         changePlayer();
         }
      }

   private void printGame()
      {
      for (int linha = 0; linha < dimension; linha++)
         {
         for (int coluna = 0; coluna < dimension; coluna++)
            {
            System.out.print("    " + getSymbol(matrix[linha][coluna]) + "    ");

            if (coluna < dimension - 1)
               {
               System.out.print("|");
               }
            }
         if (linha < dimension - 1)
            {
            System.out.println();
            System.out.println("---------|---------|---------");
            }
         }
      System.out.println();
      System.out.println();
      }

   private int readNumber(int lowerBound, int upperBound)
      {
      inputStream = new Scanner(System.in);
      int value = lowerBound - 1;

      while ((value < lowerBound) || (value >= upperBound))
         {
         value = inputStream.nextInt();
         }

      inputStream = null;
      return (value);
      }

   private boolean testEndOfGame()
      {
      boolean answer = false;

      // check lines
      answer |= ((matrix[0][0] == currentPlayer) && (matrix[0][1] == currentPlayer) && (matrix[0][2]) == currentPlayer);
      answer |= ((matrix[1][0] == currentPlayer) && (matrix[1][1] == currentPlayer) && (matrix[1][2]) == currentPlayer);
      answer |= ((matrix[2][0] == currentPlayer) && (matrix[2][1] == currentPlayer) && (matrix[2][2]) == currentPlayer);

      // check columns
      answer |= ((matrix[0][0] == currentPlayer) && (matrix[1][0] == currentPlayer) && (matrix[2][0]) == currentPlayer);
      answer |= ((matrix[0][1] == currentPlayer) && (matrix[1][1] == currentPlayer) && (matrix[2][1]) == currentPlayer);
      answer |= ((matrix[0][2] == currentPlayer) && (matrix[1][2] == currentPlayer) && (matrix[2][2]) == currentPlayer);

      // check diagonals
      answer |= ((matrix[0][0] == currentPlayer) && (matrix[1][1] == currentPlayer) && (matrix[2][2]) == currentPlayer);
      answer |= ((matrix[2][0] == currentPlayer) && (matrix[1][1] == currentPlayer) && (matrix[0][2]) == currentPlayer);

      if (answer)
         {
         System.out.println("The great winner is the player " + currentPlayer + " (" + getSymbol(currentPlayer) + ")");
         }

      return (answer);
      }

   }
