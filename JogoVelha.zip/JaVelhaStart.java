
public class JaVelhaStart
   {
   public static void main(String[] args)
      {
      System.out.println("Unicamp - Universidade Estadual de Campinas");
      System.out.println("FT - Faculdade de Tecnologia");
      System.out.println("CAF 2019 : Projeto Meu Primeiro Game");
      System.out.println("------------------------------------------------------------");
      System.out.println("JaVelha 1.0 - Jogo da Velha em Java - 17/Jan/2019.");
      System.out.println("------------------------------------------------------------");
      System.out.println();

      ControleJogo controleJogo = new ControleJogo();
      controleJogo.play();

      System.out.println();
      System.out.println("------------------------------------------------------------");
      System.out.println("Programa terminado.");
      }
   }
