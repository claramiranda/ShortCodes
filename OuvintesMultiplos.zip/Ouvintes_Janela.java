import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.HeadlessException;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class Ouvintes_Janela extends JFrame
   {
   private static final long serialVersionUID = 1L;
   private JButton           unicoBotao       = new JButton("Aperte Aqui!");
   private JPanel            painelFundo      = new JPanel();
   private JLabel            rotulo           = new JLabel("xx 01 xx");

   public Ouvintes_Janela(String title) throws HeadlessException
      {
      super(title);
      configuraJanela();
      configuraPainelERotulos();
      adicionaComponentes();
      adicionaOuvintes();
      }

   void adicionaComponentes()
      {
      this.add(painelFundo, BorderLayout.CENTER);
      this.add(unicoBotao, BorderLayout.SOUTH);
      }

   void adicionaOuvintes()
      {
      this.unicoBotao.addActionListener(new Ouvintes_Ouvinte1(this));
      this.unicoBotao.addActionListener(new Ouvintes_Ouvinte2(this));
      this.unicoBotao.addActionListener(new Ouvintes_Ouvinte3(this));
      }

   void configuraJanela()
      {
      this.setSize((int) (Toolkit.getDefaultToolkit().getScreenSize().getWidth() * 0.5 / 4),
                   (int) (Toolkit.getDefaultToolkit().getScreenSize().getHeight() * 0.15));
      this.setLocationRelativeTo(null);
      this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      this.setLayout(new BorderLayout(50, 50));
      }

   void configuraPainelERotulos()
      {
      this.painelFundo.setLayout(new BoxLayout(painelFundo, BoxLayout.Y_AXIS));

      this.rotulo.setAlignmentX(CENTER_ALIGNMENT);

      this.painelFundo.add(Box.createRigidArea(new Dimension(10, 10)));
      this.painelFundo.add(rotulo);
      this.painelFundo.add(Box.createRigidArea(new Dimension(10, 10)));

      this.painelFundo.setBackground(Color.lightGray);
      }

   void setCorPainel(Color cor)
      {
      this.painelFundo.setBackground(cor);
      }

   void setRotulo(String texto)
      {
      this.rotulo.setText(texto);
      }
   }

abstract class Ouvintes_OuvinteAbstrato implements ActionListener
   {
   protected final Ouvintes_Janela janela;

   public Ouvintes_OuvinteAbstrato(Ouvintes_Janela janela)
      {
      super();
      this.janela = janela;
      }
   }

class Ouvintes_Ouvinte1 extends Ouvintes_OuvinteAbstrato implements ActionListener
   {
   public Ouvintes_Ouvinte1(Ouvintes_Janela janela)
      {
      super(janela);
      }

   @Override
   public void actionPerformed(ActionEvent arg0)
      {
      janela.setRotulo("Mensagem do Ouvinte 1");
      }
   }

class Ouvintes_Ouvinte2 extends Ouvintes_OuvinteAbstrato implements ActionListener
   {
   public Ouvintes_Ouvinte2(Ouvintes_Janela janela)
      {
      super(janela);
      }

   @Override
   public void actionPerformed(ActionEvent arg0)
      {
      janela.setCorPainel(Color.yellow);
      }
   }

class Ouvintes_Ouvinte3 extends Ouvintes_OuvinteAbstrato implements ActionListener
   {
   public Ouvintes_Ouvinte3(Ouvintes_Janela janela)
      {
      super(janela);
      }

   @Override
   public void actionPerformed(ActionEvent arg0)
      {
      JOptionPane.showMessageDialog(janela, "Ouvinte 3", "Ouvinte atuando", JOptionPane.WARNING_MESSAGE);
      }
   }
