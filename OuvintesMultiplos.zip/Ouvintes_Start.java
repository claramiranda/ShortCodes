
public class Ouvintes_Start
   {
   public static void main(String[] args)
      {
      (new Ouvintes_Janela("Ouvintes")).setVisible(true);
      }
   }
